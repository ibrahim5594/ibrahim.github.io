<?php
/**
 * Version 3.0 update logic
 */


/* Disable font settings */
update_option( 'elementor_disable_typography_schemes', 'yes' );
update_option( 'elementor_page_title_selector', 'article-title' );

update_option( 'sweetdate-30', '1' );